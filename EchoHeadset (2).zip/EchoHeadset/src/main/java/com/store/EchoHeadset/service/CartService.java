//package com.store.EchoHeadset.service;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.store.EchoHeadset.model.Cart;
//import com.store.EchoHeadset.model.Products;
//import com.store.EchoHeadset.repository.ProductRepository;
//
//@Service
//public class CartService {
//
//@Autowired
//ProductService productService;
//
//@Autowired
//Optional<Products>  products;
//
//@Autowired
//Cart cart;
//
////product details from productservice
//
//
//
//public void getCartItem(Optional<Products> pro)
//{
//	
//	
//
//String a=pro.ge();
//cart.setName(a);
//}
//
//	
//}
