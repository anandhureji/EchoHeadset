package com.store.EchoHeadset.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.store.EchoHeadset.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Long> {

}
