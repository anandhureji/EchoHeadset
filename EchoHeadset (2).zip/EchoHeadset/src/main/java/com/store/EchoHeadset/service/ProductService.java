package com.store.EchoHeadset.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.store.EchoHeadset.model.Cart;
import com.store.EchoHeadset.model.Category;
import com.store.EchoHeadset.model.Products;
import com.store.EchoHeadset.repository.CartRepository;
import com.store.EchoHeadset.repository.CategoryRepository;
import com.store.EchoHeadset.repository.ProductRepository;

@Service
public class ProductService {
	
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	
	@Autowired
	CartRepository cartRepository;
	
	public List<Products> getAllProducts()
	{
		return productRepository.findAll();
		
		
	}
	
	
	public Optional<Products> getProductById(long p_id)
	{
		return productRepository.findById(p_id);
	
	}
	
	
	
	
	public Optional<Category> getCategoryById(long id)
	{
		return categoryRepository.findById(id);
	}
	
	public Products getAddToCart(long id)
	{
		Products pro = new Products();
		pro = productRepository.AddToCart(id);
		Cart cart = new Cart();
		cart.setName(pro.getPname());
		cart.setPrice(pro.getPrice());
		cartRepository.save(cart);
		return pro;
		
		
	}

	
	public List<Category> getAllCategory()
	{
		return categoryRepository.findAll();
		
	}	
	
	public Products deleteCartById(long id)
	{
	
		cartRepository.deleteById(id);
		return null;
	}
	
	
//	public List<Products> AddToCart(Iterable<Long> pid)
//	{
//		Products pro = new Products();
//		pro = (Products) productRepository.findAllById(pid);
//		Cart cart = new Cart();
//		cart.setName(pro.getPname());
//		cart.setPrice(pro.getPrice());
//		return (List<Products>) cartRepository.save(cart);
//		
//		
//		
//	}

	public List<Products> getProductsByCategory(String cat_id) {
		// TODO Auto-generated method stub
		return productRepository.getByCategoryId(cat_id);
	}


	public List<Cart> getAllCart() {
		// TODO Auto-generated method stub
		return cartRepository.findAll();
	}
}
