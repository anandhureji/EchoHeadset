package com.store.EchoHeadset.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.store.EchoHeadset.model.Cart;
import com.store.EchoHeadset.model.Category;
import com.store.EchoHeadset.model.Products;
import com.store.EchoHeadset.repository.CartRepository;
import com.store.EchoHeadset.repository.ProductRepository;
import com.store.EchoHeadset.service.ProductService;

@CrossOrigin
@RestController
@RequestMapping("home/product")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@Autowired
	ProductRepository productRepository;
	
	
	@Autowired
	CartRepository cartRepository;
	
	
	
	
	

	@GetMapping("getAll")
	public List<Products> getAllProducts()
	{
		return productService.getAllProducts();
		
	}
	
//	@GetMapping("getProductsByCategory")
//	public List<Products> getProductsByCategory(@RequestBody HashMap<String,String> request){
//		String category_id = request.get("cat_id");	
//		
//		return productService.getProductsByCategory(category_id);
//		
//	}
	
	@GetMapping("getProdByCat/{p_id}")
	public List<Products> getProdByCategory(@PathVariable String p_id )
	{
		return productService.getProductsByCategory(p_id);
	}
	
	
	@PostMapping("addProduct")
	public Products createProduct(@RequestBody Products product)
	{
		return productRepository.save(product);
		
	}
	
	@GetMapping("products/{p_id}")
	public Optional<Products> getById(@PathVariable String p_id)
	{
		return productService.getProductById(Long.parseLong(p_id));
	}
	
//	@GetMapping("addToCart/{p_id}")
//	public List<Products> addToCart(@PathVariable String p_id)
//	{
//		return productService.AddToCart(p_id);
//	}
	
	@GetMapping("addToCart/{p_id}")
	public Products addToCart(@PathVariable String p_id)
	{
		return productService.getAddToCart(Long.parseLong(p_id));
	}
	
	@GetMapping("getAllcart")
	public List<Cart> AllCart() {
		return productService.getAllCart();
	}
	
	@DeleteMapping("deleteFromCart/{p_id}")
	public Products deleteFromCart(@PathVariable String p_id)
	{
		return productService.deleteCartById(Long.parseLong(p_id));
	}
	
	
	
	

	@GetMapping("getAllCategory")
	public List<Category> getAllCategory()
	{
		return productService.getAllCategory();
		
	}
	
	
	@GetMapping("getAllCartProducts")
	public List<Cart> getAllCart()
	{
		return cartRepository.findAll();
	}
	
	
	@GetMapping("category/{id}")
	public Optional<Category> getCategoryById(@PathVariable String id)
	{
		return productService.getCategoryById(Long.parseLong(id));
	}
	
	
//	@GetMapping("getById")
//	public Optional<Products> getById(int pid)
//	{
//		return productService.getProductById(pid);
//	}
	
	
	
	
	
	

}
