package com.store.EchoHeadset.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class User {
	
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private long mobile;
	private String address;
	
	public User(int id, String name, long mobile, String address) {
		
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.address = address;
	}

	public User() {
		
		
	}
	

	

}
