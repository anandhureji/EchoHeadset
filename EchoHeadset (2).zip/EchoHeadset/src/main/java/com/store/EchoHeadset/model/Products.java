package com.store.EchoHeadset.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Entity
public class Products {

	@Id
	@GeneratedValue
	private long pid;
	private String pname;
	private double price;
	private String category_id;
	private String image_url;
	
	
	
	public long getPid() {
		return pid;
	}


	public void setPid(long pid) {
		this.pid = pid;
	}


	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public String getCategory_id() {
		return category_id;
	}


	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}


	public Products(long pid, String pname, double price,String category_id,String image_url) {
		
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.category_id = category_id;
		this.image_url = image_url;
	}


	public Products() {
	
	}


	public String getImage_url() {
		return image_url;
	}


	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	
	
	
	
	
}
